# Linux 命令练习环境

本目录用于练习课程中的命令，不含需要提交的作业答案。

## 目录用途

- `01-navigation`：练习 `pwd`、`cd`、`ls`、隐藏文件、软链接与时间排序。
- `02-search`：练习 `find`、`locate`、`grep`，含日志、Markdown、测试文件和大于 100 KiB 的文件。
- `03-sort`：练习普通排序、数字排序、去重以及 IP 地址排序。
- `04-permissions`：练习 `chmod`、`chown`、`chgrp`、`umask`。先用 `ls -l` 观察原始权限。
- `05-binary`：练习 `od` 查看文本和模拟 ELF 头数据。
- `06-archive`：练习 `tar`、`gzip`、`gunzip`、`zip`、`unzip`。建议先复制 `project` 再操作。

## 建议顺序

1. 从本目录执行 `pwd`、`ls`、`ls -la`、`ls -lt`。
2. 进入每个编号目录，根据上面的用途练习。
3. 将命令、输出、截图、失败原因和学习感受记录到自己的作业 Markdown 中。

提示：`locate` 依赖系统数据库，若命令不存在或找不到新文件，请记录现象和原因，不必为了练习修改系统。
