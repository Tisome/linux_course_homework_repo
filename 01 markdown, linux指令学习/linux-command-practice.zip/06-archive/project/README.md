# Demo Project
Use this directory to practise tar, gzip, zip and unzip.
