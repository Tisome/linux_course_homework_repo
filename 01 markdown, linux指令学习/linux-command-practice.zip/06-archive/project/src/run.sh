#!/usr/bin/env bash
printf "demo project running\n"
