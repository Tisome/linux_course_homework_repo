Linux command practice environment
