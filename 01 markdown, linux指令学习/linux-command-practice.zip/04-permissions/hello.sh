#!/usr/bin/env bash
echo "Hello from an executable script"
